import 'package:flutter/material.dart';
import 'dummy_menu.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Center(
        child: Text('Login Page'),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final String username;

  HomePage({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () {
                // Mengarahkan ke halaman login
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
            ),
            SizedBox(width: 8), // Menambahkan jarak antara ikon dan teks
            Text(
              'Welcome, $username',
              style: TextStyle(
                fontFamily: 'Roboto', // Ganti dengan nama font yang diinginkan
                fontWeight: FontWeight.bold,
                fontSize: 20, // Ukuran font yang lebih besar
                color: Colors.white,
                shadows: [
                  Shadow(
                    offset: Offset(1.0, 1.0), // Bayangan ke kanan bawah
                    blurRadius: 3.0, // Radius blur bayangan
                    color: Colors.black38, // Warna bayangan
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.blue[300],
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0), // Memberikan padding pada grid
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, // Jumlah kolom dalam grid
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.8, // Proporsi elemen grid
          ),
          itemCount: foodMenuList.length,
          itemBuilder: (context, index) {
            final food = foodMenuList[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              elevation: 5,
              child: InkWell(
                onTap: () {
                  // Logic untuk halaman detail makanan jika diperlukan
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.vertical(
                          top: Radius.circular(
                              15.0)), // Membuat gambar melengkung
                      child: Image.asset(
                        food.imageAsset,
                        height: 120, // Tinggi gambar
                        fit: BoxFit
                            .cover, // Gambar sesuai ukuran tanpa terpotong
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            food.name, // Nama makanan
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.blue[900],
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            food.description, // Deskripsi menu
                            style: TextStyle(
                              color: Colors.blue[600],
                            ),
                            maxLines: 2, // Membatasi jumlah baris deskripsi
                            overflow: TextOverflow
                                .ellipsis, // Memotong jika terlalu panjang
                          ),
                          SizedBox(height: 10),
                          Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.monetization_on, // Ikon mata uang
                                  color: Colors.orange[600], // Warna ikon
                                ),
                                SizedBox(
                                    width: 5), // Jarak antara ikon dan harga
                                Text(
                                  food.price, // Harga
                                  style: TextStyle(
                                    color:
                                        const Color.fromARGB(255, 248, 60, 7),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
