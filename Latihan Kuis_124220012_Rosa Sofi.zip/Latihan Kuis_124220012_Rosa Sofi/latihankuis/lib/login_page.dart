import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:latihankuis/dummy/home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isPasswordVisible = false; // State untuk mengatur visibilitas password

  void _login() {
    if (_usernameController.text.isNotEmpty &&
        _passwordController.text == "password") {
      _showSuccessDialog();
    } else {
      _showFailureSnackBar();
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.pink[50],
          title: Text(
            "Login Berhasil",
            style: TextStyle(color: const Color.fromARGB(255, 42, 42, 42)),
          ),
          content: Text(
            "Selamat datang, ${_usernameController.text}!",
            style: TextStyle(color: const Color.fromARGB(255, 3, 3, 3)),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Tutup dialog
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        HomePage(username: _usernameController.text),
                  ),
                );
              },
              child: Text(
                'OK',
                style: TextStyle(color: const Color.fromARGB(255, 43, 43, 43)),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showFailureSnackBar() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Username atau password salah."),
        backgroundColor: const Color.fromARGB(255, 218, 26, 8),
        action: SnackBarAction(
          label: 'Coba Lagi',
          onPressed: () {
            _usernameController.clear();
            _passwordController.clear();
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Hallo!',
          style: TextStyle(color: const Color.fromARGB(255, 0, 0, 0)),
        ),
        backgroundColor: const Color.fromARGB(255, 112, 160, 200),
        elevation: 0,
      ),
      body: Container(
        color: const Color.fromARGB(
            255, 205, 213, 248), // Warna latar belakang pastel
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Silahkan Login',
              style: TextStyle(
                fontSize: 28, // Ukuran font yang lebih besar
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 8, 8, 8),
                shadows: [
                  Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black38,
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.pink[50],
                labelText: 'Username',
                labelStyle:
                    TextStyle(color: const Color.fromARGB(255, 145, 145, 145)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, // Warna border hitam
                    width: 1.5, // Ketebalan border
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, // Warna border hitam saat tidak fokus
                    width: 1.5,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, // Warna border hitam saat fokus
                    width: 1.5,
                  ),
                ),
                prefixIcon: Icon(Icons.person, color: Colors.teal[300]),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _passwordController,
              obscureText: !_isPasswordVisible,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.pink[50],
                labelText: 'Password',
                labelStyle:
                    TextStyle(color: const Color.fromARGB(255, 145, 145, 145)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, // Warna border hitam
                    width: 1.5, // Ketebalan border
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, // Warna border hitam saat tidak fokus
                    width: 1.5,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, // Warna border hitam saat fokus
                    width: 1.5,
                  ),
                ),
                prefixIcon: Icon(Icons.lock, color: Colors.teal[300]),
                suffixIcon: GestureDetector(
                  onTap: () {
                    setState(() {
                      _isPasswordVisible = !_isPasswordVisible;
                    });
                  },
                  child: Icon(
                    _isPasswordVisible
                        ? Icons.visibility
                        : Icons.visibility_off,
                    color: const Color.fromARGB(255, 125, 182, 176),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _login,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(
                    255, 71, 156, 149), // Warna tombol pastel
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
              child: Text(
                'Login',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
            SizedBox(height: 20),
            Text.rich(
              TextSpan(
                text: "Don't have an account? ",
                style: TextStyle(fontSize: 16, color: Colors.black),
                children: [
                  TextSpan(
                    text: "Register",
                    style: TextStyle(
                      color: Colors.red, // Warna teks merah
                      decoration: TextDecoration
                          .underline, // Garis bawah hanya di kata Register
                    ),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () {
                        // Aksi saat di-klik, bisa diarahkan ke halaman register
                        print("Navigasi ke halaman register");
                      },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
